import React from "react";

function AllUsers() {
  return (
    <>
      <div className="head-title">
        <div className="left">
          <h1>All Applicants</h1>
          <ul className="breadcrumb">
            <li>
              <a href="/">All Applicants</a>
            </li>
            <li>
              <i className="bx bx-chevron-right"></i>
            </li>
            <li>
              <a className="active" href="/">
                Home
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="table-data d-block">
        <div className="row">
          <div className="col-md-12">
            <div className="order">
              <div className="head">
                <div className="form-input">
                  <input type="search" placeholder="Search..." />
                  <button type="submit" className="search-btn btn-warning">
                    <i className="bx bx-search"></i>
                  </button>
                </div>
              </div>
              <div className="scrollable-content">
                <table>
                  <thead>
                    <tr>
                      <th>Full Name</th>
                      <th>Mobile Number</th>
                      <th>Email</th>
                      <th>Skill</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <img
                          src={require("./dashboard/img/people.png")}
                          alt="img"
                        />
                        <p>John Doe</p>
                      </td>
                      <td>9825782269</td>
                      <td>user@yahoo.com</td>
                      <td>Python Developer</td>
                      <td>Hired</td>
                    </tr>
                    <tr>
                      <td>
                        <img
                          src={require("./dashboard/img/people.png")}
                          alt="img"
                        />
                        <p>John Doe</p>
                      </td>
                      <td>9825782269</td>
                      <td>user@yahoo.com</td>
                      <td>Java Developer</td>
                      <td>Viwed</td>
                    </tr>
                    <tr>
                      <td>
                        <img
                          src={require("./dashboard/img/people.png")}
                          alt="img"
                        />
                        <p>John Doe</p>
                      </td>
                      <td>9825782269</td>
                      <td>user@yahoo.com</td>
                      <td>Python Fullstack Developer</td>
                      <td>Qualified</td>
                    </tr>
                    <tr>
                      <td>
                        <img
                          src={require("./dashboard/img/people.png")}
                          alt="img"
                        />
                        <p>John Doe</p>
                      </td>
                      <td>9825782269</td>
                      <td>user@yahoo.com</td>
                      <td>Python Developer</td>
                      <td>Hired</td>
                    </tr>
                    <tr>
                      <td>
                        <img
                          src={require("./dashboard/img/people.png")}
                          alt="img"
                        />
                        <p>John Doe</p>
                      </td>
                      <td>9825782269</td>
                      <td>user@yahoo.com</td>
                      <td>React Developer</td>
                      <td>Pending</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default AllUsers;
